		<!--Footer Section-->
		<section class="mt-2">
		    <footer>
				<div class="row">
		            <div class="col-lg-12 m-auto text-center">
						<div class="patreon"><a href="https://www.patreon.com/bePatron?u=17793118" data-patreon-widget-type="become-patron-button">Become a Patron!</a>
							<script async src="https://c6.patreon.com/becomePatronButton.bundle.js"></script></div>

		            </div>
		        </div>
		        <div class="row mb-5">
		            <div class="col-xs-6 col-sm-6 col-md-2 col-lg-2 m-auto text-center">
		                <div class="footerLogo"> <img src="/assets/images/glaveDve.png" alt="">
		                </div>

		            </div>
		            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 ml-auto mr-0">
		                <div class="row">
							<div class="col-xs-6 col-sm-6 col-md-2 col-lg-2 text-center ">
		                        <!-- Links -->
		                        <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Subscribe</h5>

		                        <ul class="list-unstyled footerLista">
		                            <li>
		                                <a href="https://soundcloud.com/igorivladopodcast">Soundcloud</a>
		                            </li>
		                            <li>
		                                <a href="https://www.youtube.com/channel/UCdXrpoMIetYqThag7DZDAMw">Youtube</a>
		                            </li>

		                        </ul>
		                    </div>
		                    <div class="col-xs-6 col-sm-6 col-md-2 col-lg-2 text-center">
		                        <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Follow</h5>

		                        <ul class="list-unstyled footerLista">
		                            <li>
		                                <a href="https://www.instagram.com/igorivladopodcast/">Instagram </a>
		                            </li>
		                            <li>
		                                <a href="https://www.facebook.com/igorivladopodcast/">Facebook</a>
		                            </li>

		                        </ul>
		                    </div>
		                    <div class="col-xs-6 col-sm-6 col-md-2 col-lg-2 text-center">
		                        <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Sponzori</h5>

		                        <ul class="list-unstyled footerLista">
		                            <li>
		                                <a href="https://www.portalanalitika.me/">Portal Analitika</a>
		                            </li>
		                            <li>
		                                <a href="https://www.instagram.com/redbullcg/">  Red Bull CG</a>
									</li>
									<li>
		                                <a href="https://www.facebook.com/lamiacasaPG/">  La Mia Casa</a>
									</li>
									<li>
		                                <a href="https://qqriq.me/">QQRIQ</a>
									</li>
									<li>
		                                <a href="https://nordpixels.me/"> Nord Pixels</a>
									</li>
								

		                        </ul>
		                    </div>
		                    <div class="col-xs-6 col-sm-6 col-md-2 col-lg-2 text-center">
		                        <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Linkovi</h5>

		                        <ul class="list-unstyled footerLista">
		                            <li>
		                                <a href="/podcast">Podcast </a>
		                            </li>
		                            <li>
		                                <a href="/post"> Mediji</a>
									</li>
								{{-- 	<li>
		                                <a href="#!"> O nama</a>
									</li> --}}
									<li>
		                                <a href="/contact"> Saradnja</a>
		                            </li>

		                        </ul>
		                    </div>
		                    <div class="col-xs-6 col-sm-6 col-md-2 col-lg-2  text-center footerKontakt">
		                        <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Kontakt</h5>

		                        <ul class="list-unstyled footerLista">
		                            <li>
		                                <a href="#!">igorivlado@gmail.com</a>
		                            </li>
		                          

		                        </ul>
		                    </div>
		                </div>

		            </div>
		        </div>
		     
		        <div class="row">
		            <div class="bottomFooter d-flex ">

						<p> Sva prava zadržana: Igor i Vlado podcast</p>
					<a href="https://qqriq.me/" class="ml-auto mr-0 text-center"> 	<p>© 2020 QQRIQ™</p></a>
		            </div>
		        </div>

		    </footer>
		</section>
		<!--Footer Section-->
