<div style="background-color:black;height:40px;width:100%;position: fixed;bottom:0;"class="player">

</div>