<h3>You have a new email via contact form {{$name}}</h3>
<div>
    <h3> Naslov upita :{{ $subject }}</h3>

</div>
<div><p>{{$messageT}}</p></div>
<p>Sent by: {{ $email }}</p>